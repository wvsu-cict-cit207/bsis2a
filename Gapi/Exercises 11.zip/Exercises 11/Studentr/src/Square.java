public class Square {
    String studentid;
    String name;
    int grades;
    String yearandsec;


    public void  setStudentid(String studentid)
    {
        this.studentid = studentid;
    }
    public void  setName(String name)
    {
        this.studentid = name;
    }
    public void  setGrades(int grades)
    {
        this.grades = grades;
    }
    public void  setYearandsec(String yearandsec)
    {
        this.yearandsec = yearandsec;
    }

    public String getStudentid()
    {
        return studentid;
    }

    public String getName() {
        return name;
    }

    public int  getGrades() {
        return grades;
    }

    public String getYearandsec() {
        return yearandsec;
    }






    }




