import java.util.Scanner;

public class Shape {
    public static void main(String[] args) {
        Square[] squares = new Square[30];

        for (int i = 0; i < 30; i++) squares[i] = new Square();
        int size = 0, n = 0;
        int c;
        Scanner sc = new Scanner(System.in);
        String s;
        while (true) {
            System.out.print("\n\nMain Menu\n 1:Add Student record  \n 2:Delete Student record \n 3:View All \n4:Exit \nChoose one option:");

            c = sc.nextInt();

            if (c == 1) {

                System.out.print("Enter Name of the student :");

                s = sc.next();
               squares[n].setName(s);

                System.out.print("Enter the student ID number:");
                s = sc.next();
                squares[n].setStudentid(s);

                System.out.print("Enter the year and section:");
                s = sc.next();
                squares[n].setYearandsec(s);


                System.out.print("Enter grades of the Student:");
                int x = sc.nextInt();
                squares[n].setGrades(x);

                size++;
                n++;

            } else if (c == 2 && size != 0) {
                s = "";
                System.out.print("Enter index to delete :");
                c =sc.nextInt();
                squares[n].setName(s);
                squares[n].setStudentid(s);
                squares[n].setYearandsec(s);
                squares[n].setGrades(c);
                size--;
            } else if (c == 3 && size != 0) {
                int i;
                System.out.println("\nEntries in book:");
                for (i = 0; i < n; i++) {
                    System.out.println(i);
                    System.out.println("Name:" +  squares[i].getName());
                    System.out.println("Student ID:" +  squares[i].getStudentid());
                    System.out.println("Year and Section:" + squares[i].getYearandsec());
                    System.out.println("Grades:" +  squares[i].getGrades());
                    System.out.println("\n-------------------------");
                }
                

            } else if (c == 4) {
                System.out.println("\n\nThank you");
                break;
            } else {
                System.out.println("\n Enter Correct Choice\n");
            }

        }

    }

}




