public class number3 {
    public static void exit (int status){
        System.exit(0);
    }
}
