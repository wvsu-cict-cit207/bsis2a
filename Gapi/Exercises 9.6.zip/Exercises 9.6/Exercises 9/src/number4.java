public class number4 {
    public static void main(String[]args){
        double x = 3.13;
        double y = Math.floor(x);
        System.out.println(y);

    }
}
