public class Main {
    public static void main(String[]args){
        String str = "Hello";
        boolean flagg = str.endsWith("lo");
        System.out.println(flagg);
    }
}
