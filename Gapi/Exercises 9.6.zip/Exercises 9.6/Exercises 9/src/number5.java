public class number5 {
    public static void main(String[]args){
        boolean flag = Character.isDigit('3');
        System.out.println(flag);
    }
}
