import javax.swing.*;


public class calcu {

    private JPanel calcu;
    private JButton plusbtn;
    private JButton timesbtn;
    private JButton minusbtn;
    private JButton dividebtn;
    private JTextField firstnumtxtfield;
    private JTextField secondnumtxtfield;
    private JButton percentbtn;
    private JButton clearButton;
    private JTextField resulttxtfield;

    public calcu() {
        plusbtn.addActionListener(e -> {
            float n1, n2, result;
            n1 = Float.parseFloat(firstnumtxtfield.getText());
            n2 = Float.parseFloat(secondnumtxtfield.getText());

            result = n1+n2;

            resulttxtfield.setText(String.valueOf(result));


        });
        timesbtn.addActionListener(e -> {
            float n1, n2, result;
            n1 = Float.parseFloat(firstnumtxtfield.getText());
            n2 = Float.parseFloat(secondnumtxtfield.getText());

            result = n1*n2;

            resulttxtfield.setText(String.valueOf(result));

        });
        percentbtn.addActionListener(e -> {
            float n1, n2, result;
            n1 = Float.parseFloat(firstnumtxtfield.getText());
            n2 = Float.parseFloat(secondnumtxtfield.getText());

            result = n1%n2;

            resulttxtfield.setText(String.valueOf(result));
        });
        minusbtn.addActionListener(e -> {
            float n1, n2, result;
            n1 = Float.parseFloat(firstnumtxtfield.getText());
            n2 = Float.parseFloat(secondnumtxtfield.getText());

            result = n1-n2;

            resulttxtfield.setText(String.valueOf(result));
        });
        dividebtn.addActionListener(e -> {
            float n1, n2, result;
            n1 = Float.parseFloat(firstnumtxtfield.getText());
            n2 = Float.parseFloat(secondnumtxtfield.getText());

            result = n1/n2;

            resulttxtfield.setText(String.valueOf(result));
        });
        clearButton.addActionListener(e -> {
            firstnumtxtfield.setText(" ");
            secondnumtxtfield.setText(" ");
            resulttxtfield.setText(" ");
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("calcu");
        frame.setContentPane(new calcu().calcu);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
