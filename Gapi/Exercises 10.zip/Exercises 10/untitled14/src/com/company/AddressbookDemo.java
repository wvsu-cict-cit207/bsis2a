package com.company;

public class AddressbookDemo {
    public static void main(String[] args)
    {
        // Create the first instance, which will be me.
        Name startName = new Name();
        Name.setName("John Deere");
        startAddress.setAddress1();
        startAge.setAge("39");
        startPhonenumber.setPhoneNumber("6173450221");

        // Create the second instance.
        Name startName = new Name("Ewan McGregor");
        startAddress.setAddress();
        startAge.setAge("29");
        startPhonenumber.setPhoneNumber("2157679834");

        // Create the third instance.
        Name startName = new Name("Phil Mickelson");
        startAddress.setAddress();
        startAge.setAge("40");
        startPhoneNumber.setPhoneNumber("3458996787");

        // Display the data for first instance (me).
        System.out.println("Me");
        System.out.println("Name: " + startName.getName());
        System.out.println("Address: " + startAddress.getAddress());
        System.out.println("Age: " + startAge.getAge());
        System.out.println("Phonenumber: " + Phonenumber.getPhoneNumber());
        System.out.println();

        // Display the data for instance 2 (friend).
        System.out.println("Ewan McGregor");
        System.out.println("Name: " + startName.getName());
        System.out.println("Address: " + startAddress.getAddress());
        System.out.println("Age: " + startAge.getAge());
        System.out.println("PhoneNumber: " + startphoneNumber.getPhoneNumber());
        System.out.println();

        // Display the data for instance 3 (family member).
        System.out.println("Phil Mickelson");
        System.out.println("Name: " + startName.getName());
        System.out.println("Address: " + startAddress.getAddress());
        System.out.println("Age: " + startAge.getAge());
        System.out.println("PhoneNumber: " + startphoneNumber.getPhoneNumber());
        System.out.println();
    }
}
}
