package com.company;

public class Book {
    private String name1;
    private int number1;
    private String email1;
    private String address1;



    public String getName1() {
        return name1;
    }

    public int getNumber1() {
        return number1;
    }

    public String getEmail1() {
        return email1;
    }

    public String getAddress1() {
        return address1;
    }

    public void setName(String nameG) {
        name1 = nameG;
    }

    public void setNumber(int numberG) {
        number1 = numberG;
    }

    public void setEmail(String emailG) {
        email1 = emailG;
    }

    public void setAddress(String addressG) {
        address1 = addressG;
    }


    }




