package com.company;
import java.util.Scanner;

public  class Addressbookdemo {

            public static  void main(String[] args) {
                AddressBook[] addressBook = new AddressBook[100];
                Book books = new Book();

                books.setName("Izel");
                books.setNumber(5349);
                books.setEmail("Izel@gmail.com");
                books.setAddress("Iloilo City");

                System.out.println("Name: " + books.getName1());
                System.out.println("Address: " +books.getAddress1());
                System.out.println("Email: " + books.getEmail1());
                System.out.println("Phone number: " +  books.getNumber1());
                System.out.println();

                for (int i = 0; i < 100; i++) addressBook[i] = new AddressBook();

                int size = 0, n = 0;
                int c;
                Scanner sc = new Scanner(System.in);
                String s;
                int x;
                while (true) {

                    System.out.print("\n\nMain Menu\n 1:Add Entry \n 2:Delete Entry \n 3:View All Entries \n 4:Update an Entry \n 5:Exit \nChoose one option:");

                    c = sc.nextInt();

                    if (c == 1) {

                        System.out.print("Enter Name of the person in the address book :");

                        s = sc.next();
                        addressBook[n].setName(s);

                        System.out.print("Enter Address of the person:");
                        s = sc.next();
                        addressBook[n].setAddress(s);

                        System.out.print("Enter Mobile number of the person:");
                        x = sc.nextInt();
                        addressBook[n].setNumber(x);

                        System.out.print("Enter Email address of the person:");
                        s = sc.next();
                        addressBook[n].setAddress(s);

                        size++;
                        n++;

                    } else if (c == 2 && size != 0) {
                        s = "";
                        System.out.print("Enter index to delete :");
                        addressBook[n].setName(s);
                        addressBook[n].setAddress(s);
                        addressBook[n].setNumber(c);
                        addressBook[n].setEmail(s);
                        size--;

                    } else if (c == 3 && size != 0) {
                        int i;
                        System.out.println("\nEntries in book:");
                        for (i = 0; i < n; i++) {
                            System.out.println(i);
                            System.out.println("Name:" + addressBook[i].getName());
                            System.out.println("Address:" + addressBook[i].getAddress());
                            System.out.println("Mobile Number:" + addressBook[i].getNumber());
                            System.out.println("Email Address:" + addressBook[i].getEmail());
                            System.out.println("\n-------------------------");
                        }

                    } else if (c == 4 && size != 0) {
                        int m;
                        System.out.print("Enter index to update :");
                        m = sc.nextInt();
                        System.out.print("Enter Name of the person in the address book :");
                        s = sc.next();
                        addressBook[m].setName(s);

                        System.out.print("Enter Address of the person:");
                        s = sc.next();
                        addressBook[m].setAddress(s);

                        System.out.print("Enter Mobile number of the person:");
                        addressBook[m].setNumber(c);

                        System.out.print("Enter Email address of the person:");
                        s = sc.next();
                        addressBook[m].setEmail(s);


                    } else if (c == 5) {
                        System.out.println("\n\nThank you");
                        break;
                    } else {
                        System.out.println("\n Enter Correct Choice\n");
                    }

                }

            }

        }









