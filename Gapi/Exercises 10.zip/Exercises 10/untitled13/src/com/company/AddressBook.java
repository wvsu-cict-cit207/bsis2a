package com.company;



class AddressBook {
    private String name;
    private int number;
    private String email;
    private String address;

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public void setName(String nameG) {
        name = nameG;
    }

    public void setNumber(int numberG) {
        number = numberG;
    }

    public void setEmail(String emailG) {
        email = emailG;
    }

    public void setAddress(String addressG) {
        address = addressG;
    }
}




