import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;

public class CalcView {

    JLabel label1;
    JLabel label2;
    JTextField num1TF;
    JLabel label3;
    JLabel label4;
    JTextField num2TF;
    JLabel label5;
    JLabel label6;
    JLabel label;
    JButton addBtn;
    JButton minusBtn;
    JButton proBtn;
    JButton divBtn;
    JButton remBtn;
    JButton resBtn;

    public CalcView() {
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();

        label1 = new JLabel("First Number");
        label2 = new JLabel ("");
        label3 = new JLabel ("Second Number");
        label4 = new JLabel ("");
        label5 = new JLabel ("Result");
        label6 = new JLabel ("");
        label = new JLabel("");
        num1TF = new JTextField();
        num2TF = new JTextField();
        addBtn = new JButton("+");
        minusBtn = new JButton("-");
        proBtn = new JButton("*");
        divBtn = new JButton("/");
        remBtn = new JButton ("%");
        resBtn = new JButton ("CLR");

        panel.setBorder(BorderFactory.createEmptyBorder(4,4,4,4));
        panel.setLayout(new GridLayout(5,2,2,2));

        panel.add(label1);
        panel.add(label2);
        panel.add(num1TF);
        panel.add(label3);
        panel.add(label4);
        panel.add(num2TF);
        panel.add(label5);
        panel.add(label6);
        panel.add(label);
        panel.add(addBtn);
        panel.add(minusBtn);
        panel.add(proBtn);
        panel.add(divBtn);
        panel.add(remBtn);
        panel.add(resBtn);

        frame.add(panel, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Calculator");
        frame.pack();
        frame.setVisible(true);

    }

    public void allListeners(ActionListener a ) {
        addBtn.addActionListener(a);
        minusBtn.addActionListener(a);
        proBtn.addActionListener(a);
        divBtn.addActionListener(a);
        remBtn.addActionListener(a);
        resBtn.addActionListener(a);
    }

}
