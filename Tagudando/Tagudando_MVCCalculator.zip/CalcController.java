import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalcController {
    CalcView cView;
    CalcController(CalcView ccView){
        this.cView = ccView;
        ccView.allListeners(new ActionButton());


    }
    class ActionButton implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource()==cView.addBtn){
                int num1 = Integer.parseInt(cView.num1TF.getText());
                int num2 = Integer.parseInt(cView.num2TF.getText());
                int sum = CalcModel.addNumbers(num1, num2);

                cView.label.setText(""+ sum);

            }
            else if (e.getSource()==cView.minusBtn)
            {
                int num1 = Integer.parseInt(cView.num1TF.getText());
                int num2 = Integer.parseInt(cView.num2TF.getText());
                int dif = CalcModel.subNumbers(num1, num2);

                cView.label.setText(""+ dif);
            }
            else if (e.getSource()==cView.proBtn)
            {
                int num1 = Integer.parseInt(cView.num1TF.getText());
                int num2 = Integer.parseInt(cView.num2TF.getText());
                int pro = CalcModel.multiplyNumbers(num1, num2);

                cView.label.setText(""+ pro);
            }
            else if (e.getSource()==cView.divBtn)
            {
                int num1 = Integer.parseInt(cView.num1TF.getText());
                int num2 = Integer.parseInt(cView.num2TF.getText());
                int quo = CalcModel.divideNumbers(num1, num2);

                cView.label.setText(""+ quo);
            }
            else if (e.getSource()==cView.remBtn)
            {
                int num1 = Integer.parseInt(cView.num1TF.getText());
                int num2 = Integer.parseInt(cView.num2TF.getText());
                int rem = CalcModel.remainderNumbers(num1, num2);

                cView.label.setText(""+ rem);
            }
            else if (e.getSource()==cView.resBtn)
            {
                int num1 = Integer.parseInt(cView.num1TF.getText());
                int num2 = Integer.parseInt(cView.num2TF.getText());
                int res = CalcModel.resetNumbers(num1, num2);
                cView.label.setText(""+ res);
                cView.num1TF.setText(""+res);
                cView.num2TF.setText(""+res);
            }

        }

    }
}