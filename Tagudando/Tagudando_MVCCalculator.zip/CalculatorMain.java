public class CalculatorMain {
    public static void main(String[] args){
        CalcView cView = new CalcView();
        new CalcController(cView);
    }

}